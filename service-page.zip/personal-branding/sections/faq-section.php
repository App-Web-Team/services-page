<link rel="stylesheet" href="assets/styles/style-faq.css">

<section id="faq-section">
    <div class="container">
        <div class="text-center">
            <h2 class="faq-text">FAQ's</h2>
        </div>
        <div class="row justify-content-center mt-5">
            <div class="col-11">
                <div class="answer-box">
                    <p class="answer">
                        Its totally variable. As per the Each Individuals requirement and capablility, the TimeLine for personal branding would be fixed.
                        <a class="link">Click here to know more</a>
                    </p>
                    <div class="question-box">
                        <p class="question">
                            What will the approx time for personal branding?
                        </p>
                    </div>
                </div>
                <div class="answer-box add-margin">
                    <p class="answer">
                        Its totally variable. As per the Each Individuals requirement and capablility, the TimeLine for personal branding would be fixed.
                        <a class="link">Click here to know more</a>
                    </p>
                    <div class="question-box">
                        <p class="question">
                            What will the cost be for my personal branding?
                        </p>
                    </div>
                </div>
                <div class="answer-box add-margin">
                    <p class="answer">
                        Its totally variable. As per the Each Individuals requirement and capablility, the TimeLine for personal branding would be fixed.
                        <a class="link">Click here to know more</a>
                    </p>
                    <div class="question-box">
                        <p class="question">
                            What will you do in the personal branding?
                        </p>
                    </div>
                </div>
            </div>
            <div class="col-10 col-sm-12 col-lg-8 text-center">
                <button class="btn">free consultation</button>
            </div>
        </div>
</section>