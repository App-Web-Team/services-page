<link rel="stylesheet" href="assets/styles/style-callus.css">

<section id="call-us">
    <div class="container">
        <div class="row justify-content-center justify-content-sm-start">
            <div class="col-10 col-lg-6">
                <h2 class="heading">
                    why us
                </h2>
                <p class="call-us-content">
                    Lorem ipsum dolor sit amet, consectetur adipiscing elit. Nullam sit amet vestibulum enim. Aliquam venenatis commodo vehicula. Nullam aliquet faucibus ipsum eu porttitor.
                </p>
                <div class="btn-row">
                    <button class="btn btn-danger reach-btn">reach us</button>
                    <button class="btn call-btn">call us</button>
                </div>
            </div>
        </div>
    </div>
</section>