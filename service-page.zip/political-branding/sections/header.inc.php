<link rel="stylesheet" href="assets/styles/style-header.css">

<section id="header-section">
    <div class="container">
        <div class="landing-height d-flex align-items-center">
            <div class="row service-row justify-content-center align-items-end">
                <div class="col-10 col-md-6">
                    <h2 class="service-heading">
                        political branding
                    </h2>
                    <p class="service-content">
                        Lorem ipsum dolor sit amet, consectetur adipiscing elit. Nullam sit amet vestibulum enim. Aliquam venenatis commodo vehicula. Nullam aliquet faucibus ipsum eu porttitor.
                    </p>
                    <button class="btn btn-danger more-btn">
                        more information
                    </button>
                </div>
                <div class="col-8 col-sm-12 col-md-6 mt-5 mt-md-0 icon-col text-center">
                    <img src="assets/images/hand-pointer.svg" alt="" class="img-fluid pointer">
                    <img src="assets/images/ink.svg" alt="" class="img-fluid ink d-none d-sm-block">
                </div>
            </div>
        </div>
    </div>
</section>